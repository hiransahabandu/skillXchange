package com.linkedin.backend.features.messaging.dto;

public record MessageDto(Long receiverId, String content) {
}
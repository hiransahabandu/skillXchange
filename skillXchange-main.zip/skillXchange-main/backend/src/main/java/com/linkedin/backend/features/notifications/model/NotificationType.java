package com.linkedin.backend.features.notifications.model;

public enum NotificationType {
    LIKE,
    COMMENT,
}

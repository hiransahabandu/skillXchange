package com.linkedin.backend.features.authentication.dto;

public record AuthenticationResponseBody(String token, String message) {
}

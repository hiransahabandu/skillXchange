package com.linkedin.backend.dto;

public record Response(String message) {
}

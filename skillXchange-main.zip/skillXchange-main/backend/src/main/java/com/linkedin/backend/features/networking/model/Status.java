package com.linkedin.backend.features.networking.model;

public enum Status {
    PENDING,
    ACCEPTED
}
